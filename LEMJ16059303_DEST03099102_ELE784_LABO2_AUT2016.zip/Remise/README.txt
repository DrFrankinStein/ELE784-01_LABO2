Laboratoire 2 : Pilote de caméra
ELE784-01 Automne 2016

JULIEN LEMAY    (LEMJ16059303)
THIERRY DESTIN  (DEST03099102)

Arborescence : 

Exécutable : Contient les programmes compilés du pilote (Module) et de l'application de test (TestApp) avec des petits script de lancement et d'installation et désinstallation.

Source : Contient les fichiers source pour l'application de test (TestApp) et le pilote (Module) ainsi que le dossier de fichiers communs (Include)

Pour utiliser TestApp :

Appuyer sur la touche de la commande à exécuter :

Menu principal
//----------------------------------------------
Welcome to ELE784 LABO 2 Test App!
Please make a selection : 

(1) - Take photo and save it to /tmp
(2) - Move Camera
(3) - Check or edit camera option

(q) - Quit

Make a selection : 

//----------------------------------------------

1 : Permet de prendre une photo et de la sauver dans "/tmp".

2 : Permet de bouger la caméra avec 'w', 'a', 's', 'd' et reset avec 'x'

3 : Permet de lire et écrire dans les registres de la caméra (Luminosité, contraste et gain) ainsi que d'activer et désactiver le streaming.

En tout temps, 'q' sert à annuler, revenir ou quitter le programme.
