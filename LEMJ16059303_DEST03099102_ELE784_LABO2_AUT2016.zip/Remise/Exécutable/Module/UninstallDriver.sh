#!/bin/bash

sudo rmmod Laboratoire2

