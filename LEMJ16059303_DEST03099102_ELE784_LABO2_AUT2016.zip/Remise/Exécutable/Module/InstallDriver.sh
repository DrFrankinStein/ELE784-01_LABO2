#!/bin/bash

sudo insmod Laboratoire2.ko

