#!/bin/bash

./TestApp

